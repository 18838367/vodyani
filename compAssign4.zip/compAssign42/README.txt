I have not created a catch-all bash script for this assignment and so I have included 
the relevant output files that are required in the plotting scipt
